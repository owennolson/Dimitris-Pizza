# Dimitri's Pizza Website

  ## Table of Contents
  -[description](#description)
  -[installation](#installation)
  -[usage](#usage)
  -[contribution](#contribution)

  ## Description
  This was my first project I did outside of class for a real business in my home town of Weare, NH called Dimitri's Pizza. This project meant a lot to me not just because it was the first real world website created, I got to make it for a place that has been home to my favorite pizza for as long as I have lived. I reached out to them and asked if I could make their website free of charge as it was my first project and I wanted to simply build my portfolio and help a local business. I started with making them some photoshopped mock ups to see what they had in mind and they directed me little by little until we got just what they wanted. Although it took a while due to all of us having busy schedules we got it done exactly how they wanted me to make it and I directed them to buy a hosting plan on Hostinger and had them add me as a collaborator and I got he site up with no issues.

  ## Installation
  Clone GitHub Repo

  ## Usage
  Open with live server to view, or visit DimitrisPizza.net

  ## Contribution
  Owen Olson

  ## License
  N/A

  ## Tests
  N/A

  ## Questions
  If you have any questions please contact me through my Email: ono@owenolson.com. You can find more of my work at (https://api.github.com/users/owennolson)
